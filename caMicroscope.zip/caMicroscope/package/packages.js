import TestPackage from './test_package.js'

a = new TestPackage("Buildy")
