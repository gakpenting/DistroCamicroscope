import init_LocalStore from './LocalStore.js'
import ImgBoxMods from './ImgBoxMods.js'

init_LocalStore()
ImgBoxMods()
console.warn("This setup is intended for imagebox")
// parcel build package/imgbox_package.js
