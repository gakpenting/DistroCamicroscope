class TestPackage{
  constructor(text){
    console.warn("{sample package}", text)
  }
}

export default TestPackage
